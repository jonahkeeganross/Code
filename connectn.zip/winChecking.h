#ifndef WINCHECKING_H
#define WINCHECKING_H

    bool wonHorizontally(char** board, int winCon, int row_dim, int col_dim);
    bool wonDiagonally(char** board, int winCon, int row_dim, int col_dim);
    bool wonVertically(char** board, int winCon, int row_dim, int col_dim);
    bool diagonallyLeft(char** board, int winCon, int row_dim, int col_dim);
    bool diagonallyRight(char** board, int winCon, int row_dim, int col_dim);


#endif