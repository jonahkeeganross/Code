#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

/*
 * Contains the code for checking if someone has won horizontally, vertically, or diagonally
 */

bool wonHorizontally(char** board, int winCon, int row_dim, int col_dim){
    char previousPiece = '?';
    int pieces_in_a_row = 1, currentPiece;
    
    for(int i = 0; i < row_dim; i++){
        previousPiece = '?';
        pieces_in_a_row = 1;
        for(int j = 0; j < col_dim; j++){
            if(j == 0){
                continue;
            }
            if(board[i][j] == '*'){
                previousPiece = '?';
                pieces_in_a_row = 1;
                continue;
            }
            previousPiece = board[i][j - 1];
            currentPiece = board[i][j];
            if(currentPiece == previousPiece){
                pieces_in_a_row += 1;
                if(pieces_in_a_row == winCon){
                    return true;
                }
            }else{
                previousPiece = '?';
                pieces_in_a_row = 1;
            }
        }
    }
    return false;
}

bool wonVertically(char** board, int winCon, int row_dim, int col_dim){
    char previousPiece = '?';
    int pieces_in_a_row = 1, currentPiece;
    
    for(int i = 0; i < col_dim; i++){
        previousPiece = '?';
        pieces_in_a_row = 1;
        for(int j = 0; j < row_dim; j++){
            if(j == 0){
                continue;
            }
            if(board[j][i] == '*'){
                previousPiece = '?';
                pieces_in_a_row = 1;
                continue;
            }
            previousPiece = board[j - 1][i];
            currentPiece = board[j][i];
            if(currentPiece == previousPiece){
                pieces_in_a_row += 1;
                if(pieces_in_a_row == winCon){
                    return true;
                }
            }else{
                previousPiece = '?';
                pieces_in_a_row = 1;
            }
        }
    }
    return false;
}

bool diagonallyLeft(char** board, int winCon, int row_dim, int col_dim){
    char previousPiece;
    int pieces_in_a_row, currentPiece;
    
    int isOnBoard = 1;
    int shift = row_dim - 1;
    for(int i = row_dim - 1; i > 0; i--){
        previousPiece = '?';
        pieces_in_a_row = 1;
        for(int j = 0; j < row_dim; j++){
            if(j == 0){
                continue;
            }
            if(j == isOnBoard){
                break;
            }
            if(board[j + shift][j] == '*'){
                previousPiece = '?';
                pieces_in_a_row = 1;
                continue;
            }
            previousPiece = board[(j - 1) + shift][j - 1];
            currentPiece = board[j + shift][j];
            if(currentPiece == previousPiece){
                pieces_in_a_row += 1;
                if(pieces_in_a_row == winCon){
                    return true;
                }
            }else{
                previousPiece = '?';
                pieces_in_a_row = 1;
            }
        }
        shift -= 1;
        isOnBoard += 1;
    }
    shift = 0;
    isOnBoard = col_dim;
    for(int i = 0; i < col_dim; i++){
        previousPiece = '?';
        pieces_in_a_row = 1;
        for(int j = 0; j < row_dim; j++){
            if(j == 0){
                continue;
            }
            if(j >= isOnBoard){
                break;
            }
            if(board[j][j + shift] == '*'){
                previousPiece = '?';
                pieces_in_a_row = 1;
                continue;
            }
            previousPiece = board[j - 1][j - 1 + shift];
            currentPiece = board[j][j + shift];
            if(currentPiece == previousPiece){
                pieces_in_a_row += 1;
                if(pieces_in_a_row == winCon){
                    return true;
                }
            }else{
                previousPiece = '?';
                pieces_in_a_row = 1;
            }
        }
        shift += 1;
        isOnBoard -= 1;
    }
    return false;
}

bool diagonallyRight(char** board, int winCon, int row_dim, int col_dim){
    char previousPiece = '?';
    int pieces_in_a_row = 1, currentPiece;
    
    int shift = row_dim - 1;
    int isOnBoard = 1;
    for(int i = row_dim - 1; i >= 1; i--){
        previousPiece = '?';
        pieces_in_a_row = 1;
        for(int j = 0; j < row_dim; j++){
            if(j == 0){
                continue;
            }
            if(j == isOnBoard){
                break;
            }
            if(board[j + shift][col_dim - j - 1] == '*'){
                previousPiece = '?';
                pieces_in_a_row = 1;
                continue;
            }
            previousPiece = board[(j - 1) + shift][col_dim - (j - 1) - 1];
            currentPiece = board[j + shift][col_dim - j - 1];
            if(currentPiece == previousPiece){
                pieces_in_a_row += 1;
                if(pieces_in_a_row == winCon){
                    return true;
                }
            }else{
                previousPiece = '?';
                pieces_in_a_row = 1;
            }
        }
        shift -= 1;
        isOnBoard += 1;
    }
    shift = 0;
    isOnBoard = col_dim;
    for(int i = col_dim; i >= 0; i--){
        previousPiece = '?';
        pieces_in_a_row = 1;
        for(int j = 0; j < row_dim; j++){
            if(j == 0){
                continue;
            }
            if(j >= isOnBoard){
                break;
            }
            if(board[j][(col_dim - j - 1) - shift] == '*'){
                previousPiece = '?';
                pieces_in_a_row = 1;
                continue;
            }
            previousPiece = board[j - 1][(col_dim - (j - 1) - 1) - shift];
            currentPiece = board[j][(col_dim - j - 1) - shift];
            if(currentPiece == previousPiece){
                pieces_in_a_row += 1;
                if(pieces_in_a_row == winCon){
                    return true;
                }
            }else{
                previousPiece = '?';
                pieces_in_a_row = 1;
            }
        }
        shift += 1;
        isOnBoard -= 1;
    }
    return false;
}

bool wonDiagonally(char** board, int winCon, int row_dim, int col_dim){
    return diagonallyLeft(board, winCon, row_dim, col_dim) || diagonallyRight(board, winCon, row_dim, col_dim);
}