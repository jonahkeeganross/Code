#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "board.h"

/*
 * Make a program that runs a fully scalable version of connect4
 */

void playConnectN(char** board, int winCon, int* currentPlayer, int row_dim, int col_dim);
void switchPlayer(int* currentPlayer);
void announceResults(char** board, int winCon, int* currentPlayer, int row_dim, int col_dim);

int main(int argc, char** argv){
    // runs the main function
    // @argv = the three command line inputs from the user

    if(argc < 4){
        printf("Not enough arguments entered\n");
        printf("Usage connectn.out num_rows num_columns number_of_pieces_in_a_row_needed_to_win\n");
        exit(0);
    }else if(argc > 4){
        printf("Too many arguments entered\n");
        printf("Usage connectn.out num_rows num_columns number_of_pieces_in_a_row_needed_to_win\n");
        exit(0);
    }

    int row_dim = atoi(argv[1]);
    int col_dim = atoi(argv[2]);
    int winCon = atoi(argv[3]);

    if(row_dim <= 0){
        printf("error 1");
        exit(0);
    }else if(col_dim <= 0){
        printf("error 2");
        exit(0);
    }else if(winCon <= 0){
        printf("error 3");
        exit(0);
    }

    char** board;

    int currentPlayer = 1;

    board = createEmptyBoard(row_dim, col_dim);
    playConnectN(board, winCon, &currentPlayer, row_dim, col_dim);
    announceResults(board, winCon, &currentPlayer, row_dim, col_dim);

    for(int i = 0; i < row_dim; i++){
        free(board[i]);
    }
    free(board);

}

void playConnectN(char** board, int winCon, int* currentPlayer, int row_dim, int col_dim){
    while(!gameIsTied(board, row_dim, col_dim) || !someoneWon(board, winCon, row_dim, col_dim)){
        printBoard(board, row_dim, col_dim);
        placePiece(board, currentPlayer, col_dim, row_dim);
        switchPlayer(currentPlayer);
        if(gameIsTied(board, row_dim, col_dim) == true){
            break;
        }else if(someoneWon(board, winCon, row_dim, col_dim) == true){
            break;
        }
    }
    switchPlayer(currentPlayer);
    printBoard(board, row_dim, col_dim);
}

void announceResults(char** board, int winCon, int* currentPlayer, int row_dim, int col_dim){
    if(someoneWon(board, winCon, row_dim, col_dim)){
        printf("Player %d Won!\n", *currentPlayer);
    }else{
        printf("Tie game!\n");
    }
}

void switchPlayer(int* currentPlayer){
    //switch the player
    if(*currentPlayer == 2){
        *currentPlayer = 1;
    }else{
        *currentPlayer = 2;
    }
}