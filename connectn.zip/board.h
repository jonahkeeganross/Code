#ifndef BOARD_H
#define BOARD_H

    char** createEmptyBoard(int row_dim, int col_dim);
    void printBoard(char** board, int row_dim, int col_dim);
    void placePiece(char** board, int* currentPlayer, int col_dim, int row_dim);
    bool gameIsTied(char** board, int row_dim, int col_dim);
    bool someoneWon(char** board, int winCon, int row_dim, int col_dim);

#endif