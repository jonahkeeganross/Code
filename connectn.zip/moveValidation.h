#ifndef MOVEVALIDATION_H
#define MOVEVALIDATION_H

    int getPlayerMove(int col_dim);
    bool col_is_full(int playerMove, char** board);
    bool isValidFormat(const int numArgsRead, const int numArgsNeed);    
    int getValidInt(const bool isLastElementOnLine);

#endif