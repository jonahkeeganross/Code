#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

bool isValidFormat(const int numArgsRead, const int numArgsNeed) {
    bool formatIsGood = numArgsRead == numArgsNeed;
    char character;
    do{
        scanf("%c", &character); //45  bob  \n
            if(!isspace(character)){ //found a non whitespace character on the way to the end of the line
                formatIsGood = false;
            }
        }while(character != '\n'); //read characters until the end of the line
    return formatIsGood;
}


int getValidInt() {
    const int numArgsNeeded = 1;
    int numArgsRead;
    int num;

    numArgsRead = scanf(" %d", &num);
    if (isValidFormat(numArgsNeeded, numArgsRead)) {
        return num;
    } else {
        return -1;
    }
}

bool col_is_full(int playerMove, char** board){
    // checks if the collumn is full

    if(board[0][playerMove] == '*'){
        return false;
    }
    return true;
}

int getPlayerMove(int col_dim){

    int playerMove;

    do{
        printf("Enter a column between 0 and %d to play in: ", col_dim - 1);
        playerMove = getValidInt();
    }while(playerMove < 0 || playerMove > col_dim);

    return playerMove;
}