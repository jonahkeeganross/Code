#include <stdio.h>
#include <stdbool.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include "moveValidation.h"
#include "winChecking.h"

char** createEmptyBoard(int row_dim, int col_dim){
    // create an empty matrix to use as the board for the rest of the game

    char** board = (char**)calloc(row_dim, sizeof(char*));
    for(int i = 0; i < row_dim; i++){
        board[i] = (char*)calloc(col_dim, sizeof(char));
        for(int j = 0; j < col_dim; j++){
            board[i][j] = '*';
        }
    }

    return board;
}

void printBoard(char** board, int row_dim, int col_dim){
    //print the board
    for(int i = 0; i < row_dim; i++){
        printf("%d ", row_dim - 1 - i);
        for(int j = 0; j < col_dim; j++){
            printf("%c ", board[i][j]);
        }
        printf("\n");
    }
    printf("  ");
    for(int i = 0; i < col_dim; i++){
        printf("%d ", i);
    }
    printf("\n");
}

void placePiece(char** board, int* currentPlayer, int col_dim, int row_dim){
    // places the piece on the board
    char playerPiece = '?';
    int playerMove;

    if(*currentPlayer == 1){
        playerPiece = 'X';
    }else if(*currentPlayer == 2){
        playerPiece = 'O';
    }

    do{
        playerMove = getPlayerMove(col_dim);
    }while(col_is_full(playerMove, board));

    for(int i = 0; i < row_dim; i++){
        if(board[i][playerMove] != '*'){
            board[i - 1][playerMove] = (char)playerPiece;
            break;
        }
        else if(i == row_dim - 1){
            board[i][playerMove] = (char)playerPiece;
            break;
        }
    }
}

bool gameIsTied(char** board, int row_dim, int col_dim){
    // checks if the game is tied
    for(int i = 0; i < row_dim; i++){
        for(int j = 0; j < col_dim; j++){
            if(board[i][j] == '*'){
                return false;
            }
        }
    }
    return true;
}

bool someoneWon(char** board, int winCon, int row_dim, int col_dim){
    // checks if someone has won
    return wonHorizontally(board, winCon, row_dim, col_dim) || wonVertically(board, winCon, row_dim, col_dim) || wonDiagonally(board, winCon, row_dim, col_dim);
}