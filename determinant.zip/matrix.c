#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"

// typedef struct Matrix_struct{

//     int** baseMatrix;

//     int dimension;

// }Matrix;

void createMatrix(int dimension, long double** *baseMatrix){
    *baseMatrix = (long double**)calloc(dimension, sizeof(long double*));
    for(int i = 0; i < dimension; i++){
        (*baseMatrix)[i] = (long double*)calloc(dimension, sizeof(long double));
    }
}

void fillMatrix(FILE* fp, long double** *matrix, int dimension){
    for(int i = 0; i < dimension; i++){
        for(int j = 0; j < dimension; j++){
            fscanf(fp, "%Lf", &(*matrix)[i][j]);
        }
    }
}