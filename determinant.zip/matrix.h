#ifndef MATRIX_H
    #define MATRIX_H
    typedef struct Matrix_struct{

    long double** baseMatrix;

    int dimension;

    }Matrix;
    void createMatrix(int dimension, long double** *baseMatrix);
    void fillMatrix(FILE* fp, long double** *matrix, int dimension);
#endif