#include <stdio.h>
#include <stdlib.h>

#include "matrix.h"

/*
 * Write a program that recursively finds the determinant of a given matrix
 */

long double findDeterminant(long double** matrix, int dimension);

int main(int argc, char* argv[]){
    // runs the main function

    if(argc != 2){
        exit(0);
    }

    char* fileDir = argv[1];
    FILE* fp = fopen(fileDir, "r");
    
    Matrix initialMatrix;

    fscanf(fp, "%d", &initialMatrix.dimension);
    fscanf(fp, " %d", &initialMatrix.dimension);

    int dimension = initialMatrix.dimension;
    long double** baseMatrix;

    createMatrix(dimension, &baseMatrix);

    initialMatrix.baseMatrix = baseMatrix;

    fillMatrix(fp, &initialMatrix.baseMatrix, dimension);

    // for(int i = 0; i < dimension; i++){
    //     for(int j = 0; j < dimension; j++){
    //         printf("%.2lf ", baseMatrix[i][j]);
    //     }
    //     printf("\n");
    // }

    long double finalDeterminant = findDeterminant(baseMatrix, dimension);
    printf("The determinant is %.2Lf.\n", finalDeterminant);
}

long double findDeterminant(long double** matrix, int dimension){
    if(dimension == 1){
        return matrix[0][0];
    }
    if(dimension == 2){
        return ((matrix[0][0] * matrix[1][1]) - (matrix[0][1] * matrix[1][0]));
    }
    else{
        long double** tempMatrix = (long double**)calloc(dimension - 1, sizeof(long double*));
        for(int i = 0; i < dimension; i++){
            tempMatrix[i] = (long double*)calloc(dimension - 1, sizeof(long double));
        }
        long double result = 0;
        int signMultiplier = 1;
        for(int k = 0; k < dimension; k ++){
            int y_count = 0;
            for(int i = 1; i < dimension; i ++){
                int x_count = 0;
                for(int j = 0; j < dimension; j++){
                    if(j == k){
                        continue;
                    }
                    tempMatrix[x_count][y_count] = matrix[i][j];
                    x_count++;
                }
                y_count++;
            }
            result += signMultiplier * matrix[0][k] * findDeterminant(tempMatrix, dimension - 1);
            signMultiplier = signMultiplier * -1;
        }
        return result;
    }
}